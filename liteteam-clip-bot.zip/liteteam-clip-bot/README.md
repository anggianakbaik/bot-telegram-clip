# Lite Team Clip — Bot Telegram

Bot Telegram buat clip video YouTube otomatis, kualitas **maksimal**: potong
durasi, orientasi potret/lanskap dengan background blur (bukan hard-crop),
caption otomatis animasi ala Shorts/TikTok dengan font & warna custom, audio
di-normalize biar konsisten, thumbnail otomatis dengan teks hook, lalu upload
langsung ke YouTube.

Semua tool yang dipakai **gratis & open-source**: yt-dlp, ffmpeg, whisper.cpp,
YouTube Data API (gratis dengan kuota harian). Font bawaan (Poppins Bold,
Anton) juga gratis & bebas didistribusikan (lisensi SIL Open Font License).

> ✅ Bagian video processing (pad+blur, caption animasi, thumbnail) sudah
> ditest langsung pakai ffmpeg beneran selama development — bukan cuma teori.
> Bagian yang butuh kredensial asli (login YouTube, token bot Telegram) tetap
> perlu kamu setup & coba sendiri karena sifatnya personal/rahasia.

## Fitur

- **Clip presisi**: input timestamp mulai & akhir, cuma bagian itu yang
  di-download (hemat waktu & storage, gak perlu download video 3 jam penuh).
- **Orientasi potret/lanskap dengan pad+blur**: frame asli tetap 100% utuh,
  ruang kosong diisi versi blur dari video itu sendiri — bukan dipotong paksa,
  bukan juga bar hitam polos.
- **Caption otomatis animasi**: transkrip whisper dipecah jadi frasa pendek
  (3-4 kata) yang muncul cepat & catchy dengan animasi pop, mirip gaya editor
  Shorts/Reels profesional. Font & warna bisa custom.
- **Audio loudness normalization**: volume dinormalisasi ke standar YouTube
  (-14 LUFS) biar konsisten, penonton gak perlu naik-turunin volume.
- **Thumbnail otomatis**: ambil frame dari video + tempel teks hook besar/bold
  dari judul, otomatis diset jadi thumbnail YouTube kalau upload.
- **Upload otomatis** ke YouTube dengan judul/deskripsi/hashtag/privasi/tipe
  (Shorts/Video Biasa) yang kamu isi lewat chat.

## 1. Persiapan akun YouTube (WAJIB, dilakukan di PC lokal kamu)

Bot upload ke YouTube pakai OAuth Google. Proses login browser-nya **tidak bisa**
dilakukan langsung di panel Pterodactyl (karena panel biasanya tanpa browser/GUI),
jadi harus disiapkan dulu di PC/laptop kamu:

1. Buka https://console.cloud.google.com/, buat project baru.
2. Aktifkan **YouTube Data API v3** (API & Services > Library).
3. Buat credential: API & Services > Credentials > Create Credentials > OAuth Client ID
   - Application type: **Desktop app**
4. Download JSON-nya, rename jadi `client_secret.json`.
5. Di PC lokal, install Node.js, lalu di folder project ini jalankan:
   ```
   npm install googleapis
   node authorize.js
   ```
6. Browser kebuka, login & izinkan akses. Setelah selesai, file `token.json`
   otomatis muncul di folder yang sama.
7. **Upload `client_secret.json` dan `token.json` ke panel Pterodactyl**, taruh
   sejajar dengan `index.js` (di root folder bot).

> 💡 Thumbnail custom (fitur otomatis di atas) cuma bisa dipasang lewat API
> kalau channel YouTube kamu sudah **verified nomor HP**
> (Studio > Settings > Channel > Feature eligibility). Kalau belum verified,
> video tetap keupload normal, cuma thumbnail-nya pakai auto-pilih YouTube.

## 2. Setup bot Telegram

1. Chat **@BotFather** di Telegram, `/newbot`, ikuti instruksi, kasih nama
   **Lite Team Clip** (atau username sesuai keinginan kamu).
2. Simpan token yang dikasih BotFather.
3. Di panel Pterodactyl, buka Startup/Variables, isi `BOT_TOKEN` dengan token itu
   (atau edit langsung file `.env`, copy dari `.env.example`).
4. (Opsional) isi `ALLOWED_USER_ID` dengan Telegram ID kamu (dari @userinfobot)
   biar bot cuma bisa dipakai kamu sendiri.

## 3. Upload ke Pterodactyl

1. Zip seluruh folder ini (kecuali `node_modules` kalau ada — sudah dibersihkan
   di paket ini, `npm install` akan generate ulang sesuai arsitektur server kamu).
2. Di panel Pterodactyl, pastikan egg/server pakai **Node.js**.
3. Upload & extract zip ke folder server.
4. Masuk ke Console/Terminal panel, jalankan:
   ```
   npm install
   ```
5. Set **Startup Command** jadi:
   ```
   node index.js
   ```
6. Start server.

### Catatan penting soal environment Pterodactyl

- **`ffmpeg`** ke-install otomatis lewat paket `ffmpeg-static` saat `npm install`
  (download binary dari GitHub Releases). **Kalau `npm install` gagal di paket
  ini** dengan error semacam "API rate limit exceeded" dari GitHub — itu artinya
  IP server kamu lagi kena rate-limit GitHub API (bukan error di kode). Solusi:
  tunggu beberapa menit lalu `npm install` ulang, atau jalankan
  `npm install --ignore-scripts` dulu baru `node node_modules/ffmpeg-static/install.js`
  terpisah untuk retry cuma bagian itu.
- **`yt-dlp`** juga otomatis lewat `youtube-dl-exec` (bundled binary, mekanisme
  download sama seperti di atas — kalau gagal, penyebab & solusinya sama).
- **`ffprobe-static`** sudah bundled langsung di dalam package-nya, tidak perlu
  download apa-apa — ini paling anti-gagal dari ketiganya.
- **Whisper (subtitle otomatis)** butuh build tools (`make`, `g++`) untuk compile
  whisper.cpp saat `npm install`. Kalau container Pterodactyl kamu berbasis image
  minimal tanpa build tools, proses transkrip bisa gagal. Kalau itu terjadi:
  - Cek apakah panel kamu bisa ganti Docker image Node.js ke yang include
    `build-essential` (tanya admin panel/hosting kamu), atau
  - Fitur subtitle bisa di-skip (tetap pilih "OFF" saat pakai bot), fitur
    lain (download, clip, orientasi, thumbnail, upload) tetap jalan normal.
- Model whisper (~150MB untuk model "base") ke-download otomatis saat pertama
  kali fitur subtitle dipakai — pastikan storage panel cukup & ada koneksi internet.

## 4. Cara pakai bot

1. Chat bot kamu, ketik `/clip`
2. Kirim link YouTube video sumber
3. Kirim durasi mulai & akhir, contoh: `1:00:00 1:15:20`
4. Pilih orientasi: Potret / Lanskap
5. Pilih subtitle: ON / OFF
   - Kalau ON: upload file font `.ttf`/`.otf` (atau ketik `default` — pakai
     Poppins Bold bawaan), lalu kirim kode warna hex, contoh `#ff0000`
6. Pilih: Upload ke YouTube / Simpan saja di server
   - Kalau upload: isi judul, deskripsi, hashtag, tipe (Shorts/Video Biasa),
     privasi — thumbnail otomatis dibuat dari judul ini
7. Bot proses otomatis & kirim hasil/link videonya.

Ketik `/cancel` kapan saja buat batalin proses yang sedang jalan.

## Struktur folder

```
liteteam-clip-bot/
├── index.js                   # entry point bot
├── authorize.js                # jalankan sekali di PC lokal buat generate token.json
├── package.json
├── .env.example
├── fonts/
│   └── default/                # font bawaan (Poppins Bold, Anton) - gratis, OFL license
├── temp/                       # folder kerja sementara
├── hasil_clip/                 # video hasil (kalau user pilih "simpan saja")
└── src/
    ├── config.js               # path terpusat (font default, temp, dll)
    ├── session.js
    ├── scenes/
    │   └── clipScene.js        # alur wizard percakapan lengkap
    ├── services/
    │   ├── youtubeDownload.js  # download section video via yt-dlp
    │   ├── videoProcess.js     # pad+blur orientasi + loudness normalize + color grade
    │   ├── subtitle.js         # transkrip whisper -> caption .ass animasi + burn
    │   ├── thumbnail.js        # generate thumbnail otomatis + teks hook
    │   └── youtubeUpload.js    # upload ke YouTube + set thumbnail custom
    └── utils/
        ├── time.js
        └── color.js
```

## Batasan yang perlu diketahui

- Kuota YouTube Data API gratis: 10.000 unit/hari, 1 upload = ~1.600 unit
  (jadi ±6 video/hari lewat API, tanpa biaya apapun).
- Caption otomatis huruf besar semua (UPPERCASE) sebagai gaya default ala
  Shorts — kalau mau lowercase/normal, tinggal ubah `.toUpperCase()` di
  `src/services/subtitle.js` (fungsi `buildAssFromSrt`).
- Font custom dibaca nama family-nya otomatis dari file font (bukan dari nama
  file), tapi kalau font punya struktur internal yang aneh, ffmpeg mungkin
  fallback ke font sistem.
- Thumbnail custom via API butuh channel YouTube yang sudah verified nomor HP
  (lihat catatan di bagian setup akun YouTube).
- Sesi percakapan disimpan di memory — kalau bot restart di tengah proses,
  sesi yang sedang berjalan akan hilang (harus mulai `/clip` lagi).
