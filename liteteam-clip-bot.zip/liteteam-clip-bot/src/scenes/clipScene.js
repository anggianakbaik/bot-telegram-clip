const { Scenes, Markup } = require("telegraf");
const fs = require("fs");
const path = require("path");
const os = require("os");

const { timeToSeconds } = require("../utils/time");
const { isValidHex } = require("../utils/color");
const { downloadYoutubeSection } = require("../services/youtubeDownload");
const { processOrientation } = require("../services/videoProcess");
const { transcribeToSrt, buildAssFromSrt, burnSubtitle } = require("../services/subtitle");
const { generateThumbnail } = require("../services/thumbnail");
const { uploadVideo } = require("../services/youtubeUpload");

const TEMP_DIR = path.join(__dirname, "..", "..", "temp");
const FONTS_DIR = path.join(__dirname, "..", "..", "fonts");

function cleanup(filePaths) {
  for (const p of filePaths) {
    try {
      if (p && fs.existsSync(p)) fs.unlinkSync(p);
    } catch (_) {
      /* abaikan error cleanup */
    }
  }
}

const clipScene = new Scenes.WizardScene(
  "CLIP_SCENE",

  // Step 0: minta link YouTube
  async (ctx) => {
    await ctx.reply("🔗 Kirim link YouTube video yang mau di-clip:");
    return ctx.wizard.next();
  },

  // Step 1: terima link, minta durasi mulai & akhir
  async (ctx) => {
    const text = ctx.message?.text?.trim();
    if (!text || !text.includes("youtu")) {
      await ctx.reply("❌ Itu bukan link YouTube yang valid. Kirim ulang linknya:");
      return; // tetap di step ini
    }
    ctx.wizard.state.data = { youtubeUrl: text };
    await ctx.reply(
      "⏱️ Kirim durasi mulai & akhir clip, format: `mulai akhir`\n" +
        "Contoh: `1:00:00 1:15:20`",
      { parse_mode: "Markdown" }
    );
    return ctx.wizard.next();
  },

  // Step 2: terima durasi, tanya orientasi
  async (ctx) => {
    const text = ctx.message?.text?.trim();
    const parts = text ? text.split(/\s+/) : [];
    if (parts.length !== 2) {
      await ctx.reply("❌ Format salah. Kirim dua waktu dipisah spasi, contoh: `1:00:00 1:15:20`", {
        parse_mode: "Markdown",
      });
      return;
    }
    const startSec = timeToSeconds(parts[0]);
    const endSec = timeToSeconds(parts[1]);
    if (startSec === null || endSec === null || endSec <= startSec) {
      await ctx.reply("❌ Waktu tidak valid, atau waktu akhir harus lebih besar dari waktu mulai. Coba lagi:");
      return;
    }

    ctx.wizard.state.data.startSec = startSec;
    ctx.wizard.state.data.endSec = endSec;

    await ctx.reply(
      "📐 Pilih bentuk video:",
      Markup.inlineKeyboard([
        Markup.button.callback("📱 Potret (berdiri, 9:16)", "orient_portrait"),
        Markup.button.callback("🖥️ Lanskap (miring, 16:9)", "orient_landscape"),
      ])
    );
    return ctx.wizard.next();
  },

  // Step 3: terima orientasi, tanya subtitle on/off
  async (ctx) => {
    if (ctx.updateType !== "callback_query") {
      await ctx.reply("Pilih salah satu tombol di atas ya 🙏");
      return;
    }
    const choice = ctx.callbackQuery.data;
    await ctx.answerCbQuery();
    ctx.wizard.state.data.orientation = choice === "orient_portrait" ? "portrait" : "landscape";

    await ctx.editMessageText(
      `📐 Bentuk dipilih: ${ctx.wizard.state.data.orientation === "portrait" ? "Potret 9:16" : "Lanskap 16:9"}`
    );
    await ctx.reply(
      "💬 Subtitle otomatis mau di-ON atau OFF?",
      Markup.inlineKeyboard([
        Markup.button.callback("✅ ON", "sub_on"),
        Markup.button.callback("🚫 OFF", "sub_off"),
      ])
    );
    return ctx.wizard.next();
  },

  // Step 4: terima pilihan subtitle
  async (ctx) => {
    if (ctx.updateType !== "callback_query") {
      await ctx.reply("Pilih salah satu tombol di atas ya 🙏");
      return;
    }
    const choice = ctx.callbackQuery.data;
    await ctx.answerCbQuery();
    const subtitleOn = choice === "sub_on";
    ctx.wizard.state.data.subtitleOn = subtitleOn;

    await ctx.editMessageText(`💬 Subtitle: ${subtitleOn ? "ON" : "OFF"}`);

    if (subtitleOn) {
      await ctx.reply(
        "🔤 Kirim file font (.ttf/.otf) yang mau dipakai untuk subtitle.\n" +
          "Atau ketik `default` kalau mau pakai font bawaan (Poppins Bold)."
      );
      return ctx.wizard.next();
    } else {
      return ctx.wizard.selectStep(6); // lompat ke step pilihan upload
    }
  },

  // Step 5a: terima font, lanjut tanya warna
  async (ctx) => {
    if (ctx.message?.document) {
      const doc = ctx.message.document;
      const ext = path.extname(doc.file_name || "").toLowerCase();
      if (![".ttf", ".otf"].includes(ext)) {
        await ctx.reply("❌ File harus format .ttf atau .otf. Kirim ulang, atau ketik `default`:");
        return;
      }
      const fileLink = await ctx.telegram.getFileLink(doc.file_id);
      const destPath = path.join(FONTS_DIR, `${Date.now()}_${doc.file_name}`);
      const res = await fetch(fileLink.href);
      const buffer = Buffer.from(await res.arrayBuffer());
      fs.writeFileSync(destPath, buffer);
      ctx.wizard.state.data.fontPath = destPath;
      await ctx.reply(`✅ Font "${doc.file_name}" tersimpan.`);
    } else if (ctx.message?.text?.trim().toLowerCase() === "default") {
      ctx.wizard.state.data.fontPath = null;
      await ctx.reply("✅ Pakai font default.");
    } else {
      await ctx.reply("❌ Kirim file .ttf/.otf, atau ketik `default`:");
      return;
    }

    await ctx.reply("🎨 Kirim kode warna subtitle, format hex. Contoh: `#ff0000`", {
      parse_mode: "Markdown",
    });
    return ctx.wizard.next();
  },

  // Step 5b: terima warna
  async (ctx) => {
    const text = ctx.message?.text?.trim();
    if (!text || !isValidHex(text)) {
      await ctx.reply("❌ Format warna salah. Kirim hex 6 digit, contoh: `#ff0000`", {
        parse_mode: "Markdown",
      });
      return;
    }
    ctx.wizard.state.data.colorHex = text;
    await ctx.reply(`✅ Warna subtitle: ${text}`);
    return ctx.wizard.selectStep(6);
  },

  // Step 6: tanya mau upload ke YouTube atau simpan saja
  async (ctx) => {
    await ctx.reply(
      "📤 Video hasil clip mau langsung diupload ke YouTube, atau disimpan di server saja?",
      Markup.inlineKeyboard([
        Markup.button.callback("🚀 Upload ke YouTube", "action_upload"),
        Markup.button.callback("💾 Simpan saja", "action_save"),
      ])
    );
    return ctx.wizard.next();
  },

  // Step 7: proses pilihan upload/simpan
  async (ctx) => {
    if (ctx.updateType !== "callback_query") {
      await ctx.reply("Pilih salah satu tombol di atas ya 🙏");
      return;
    }
    const choice = ctx.callbackQuery.data;
    await ctx.answerCbQuery();
    ctx.wizard.state.data.uploadToYoutube = choice === "action_upload";
    await ctx.editMessageText(
      choice === "action_upload" ? "🚀 Upload ke YouTube dipilih." : "💾 Simpan saja dipilih."
    );

    if (!ctx.wizard.state.data.uploadToYoutube) {
      return runPipeline(ctx);
    }

    await ctx.reply("📝 Kirim judul video:");
    return ctx.wizard.next();
  },

  // Step 8: judul
  async (ctx) => {
    const text = ctx.message?.text?.trim();
    if (!text) {
      await ctx.reply("❌ Judul tidak boleh kosong. Kirim judulnya:");
      return;
    }
    ctx.wizard.state.data.judul = text;
    await ctx.reply("📄 Kirim deskripsi video (atau ketik `-` kalau tidak ada):");
    return ctx.wizard.next();
  },

  // Step 9: deskripsi
  async (ctx) => {
    const text = ctx.message?.text?.trim();
    ctx.wizard.state.data.deskripsi = text === "-" ? "" : text || "";
    await ctx.reply("🏷️ Kirim hashtag, pisah spasi (contoh: `#viral #shorts`), atau ketik `-` kalau tidak ada:");
    return ctx.wizard.next();
  },

  // Step 10: hashtag
  async (ctx) => {
    const text = ctx.message?.text?.trim();
    ctx.wizard.state.data.hashtags =
      text && text !== "-" ? text.split(/\s+/).filter(Boolean) : [];

    await ctx.reply(
      "🎬 Tipe video:",
      Markup.inlineKeyboard([
        Markup.button.callback("📱 Shorts", "type_shorts"),
        Markup.button.callback("🎞️ Video Biasa", "type_long"),
      ])
    );
    return ctx.wizard.next();
  },

  // Step 11: tipe video, lalu tanya privasi
  async (ctx) => {
    if (ctx.updateType !== "callback_query") {
      await ctx.reply("Pilih salah satu tombol di atas ya 🙏");
      return;
    }
    const choice = ctx.callbackQuery.data;
    await ctx.answerCbQuery();
    ctx.wizard.state.data.tipe = choice === "type_shorts" ? "shorts" : "long";
    await ctx.editMessageText(`🎬 Tipe: ${ctx.wizard.state.data.tipe === "shorts" ? "Shorts" : "Video Biasa"}`);

    await ctx.reply(
      "🔒 Privasi video:",
      Markup.inlineKeyboard([
        Markup.button.callback("🌍 Public", "priv_public"),
        Markup.button.callback("🔗 Unlisted", "priv_unlisted"),
        Markup.button.callback("🔒 Private", "priv_private"),
      ])
    );
    return ctx.wizard.next();
  },

  // Step 12: privasi, lalu jalankan semua proses
  async (ctx) => {
    if (ctx.updateType !== "callback_query") {
      await ctx.reply("Pilih salah satu tombol di atas ya 🙏");
      return;
    }
    const choice = ctx.callbackQuery.data;
    await ctx.answerCbQuery();
    ctx.wizard.state.data.privasi = choice.replace("priv_", "");
    await ctx.editMessageText(`🔒 Privasi: ${ctx.wizard.state.data.privasi}`);

    return runPipeline(ctx);
  }
);

/**
 * Jalankan seluruh proses: download section -> crop orientasi -> subtitle (opsional)
 * -> upload ke YouTube (opsional) atau simpan.
 */
async function runPipeline(ctx) {
  const data = ctx.wizard.state.data;
  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), "clip-"));
  const filesToClean = [];

  try {
    await ctx.reply("⏳ Mendownload bagian video dari YouTube...");
    const sourcePath = await downloadYoutubeSection(data.youtubeUrl, data.startSec, data.endSec, workDir);
    filesToClean.push(sourcePath);

    await ctx.reply("✂️ Memotong & menyesuaikan orientasi video (HD)...");
    const croppedPath = path.join(workDir, "cropped.mp4");
    await processOrientation(sourcePath, croppedPath, data.orientation);
    filesToClean.push(croppedPath);

    let finalPath = croppedPath;

    if (data.subtitleOn) {
      await ctx.reply("📝 Membuat subtitle otomatis (whisper), ini bisa agak lama...");
      const srtPath = await transcribeToSrt(croppedPath, process.env.WHISPER_LANG || "id");
      filesToClean.push(srtPath);

      await ctx.reply("🎨 Menyusun caption (animasi pop, frasa pendek) & menempelkan ke video...");
      const assPath = path.join(workDir, "captions.ass");
      buildAssFromSrt(srtPath, {
        fontPath: data.fontPath,
        colorHex: data.colorHex || "#ffffff",
        orientation: data.orientation,
        outputPath: assPath,
      });
      filesToClean.push(assPath);

      const subbedPath = path.join(workDir, "final.mp4");
      const fontDir = data.fontPath ? path.dirname(data.fontPath) : undefined;
      await burnSubtitle(croppedPath, assPath, fontDir, subbedPath);
      filesToClean.push(subbedPath);
      finalPath = subbedPath;
    }

    let thumbnailPath = null;
    if (data.uploadToYoutube) {
      await ctx.reply("🖼️ Membuat thumbnail otomatis (teks hook dari judul)...");
      thumbnailPath = path.join(workDir, "thumbnail.jpg");
      await generateThumbnail(
        finalPath,
        data.judul,
        { fontPath: data.fontPath, colorHex: data.colorHex },
        thumbnailPath
      );
      filesToClean.push(thumbnailPath);

      await ctx.reply("🚀 Mengupload video ke YouTube...");
      const { videoId, thumbnailSet } = await uploadVideo({
        videoPath: finalPath,
        judul: data.judul,
        deskripsi: data.deskripsi,
        hashtags: data.hashtags,
        tipe: data.tipe,
        privasi: data.privasi,
        thumbnailPath,
      });
      await ctx.reply(
        `✅ Selesai! Video sudah keupload:\nhttps://youtu.be/${videoId}` +
          (thumbnailSet
            ? "\n🖼️ Thumbnail custom berhasil dipasang."
            : "\n⚠️ Thumbnail custom gagal dipasang (channel mungkin belum verified nomor HP), pakai thumbnail auto-pilih YouTube.")
      );
    } else {
      const savedDir = path.join(__dirname, "..", "..", "hasil_clip");
      fs.mkdirSync(savedDir, { recursive: true });
      const savedPath = path.join(savedDir, `clip_${Date.now()}.mp4`);
      fs.copyFileSync(finalPath, savedPath);
      await ctx.reply(`✅ Selesai! Video tersimpan di server:\n${savedPath}`);
    }
  } catch (err) {
    console.error(err);
    await ctx.reply(`❌ Terjadi error: ${err.message}`);
  } finally {
    cleanup(filesToClean);
    try {
      fs.rmSync(workDir, { recursive: true, force: true });
    } catch (_) {}
    return ctx.scene.leave();
  }
}

module.exports = clipScene;
