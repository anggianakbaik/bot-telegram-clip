/**
 * Validasi hex color format "#RRGGBB" atau "RRGGBB".
 */
function isValidHex(hex) {
  return /^#?[0-9A-Fa-f]{6}$/.test(hex.trim());
}

/**
 * Konversi "#RRGGBB" ke format warna ASS/SSA yang dipakai ffmpeg subtitle filter.
 * ASS pakai urutan AABBGGRR (alpha, biru, hijau, merah), alpha 00 = solid/opaque.
 * Hasil: "&H00BBGGRR&"
 */
function hexToAssColor(hex) {
  const clean = hex.trim().replace("#", "");
  const r = clean.substring(0, 2);
  const g = clean.substring(2, 4);
  const b = clean.substring(4, 6);
  return `&H00${b}${g}${r}&`.toUpperCase();
}

module.exports = { isValidHex, hexToAssColor };
