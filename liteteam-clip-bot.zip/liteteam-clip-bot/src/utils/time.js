/**
 * Parse timestamp format "H:MM:SS" atau "MM:SS" atau "SS" ke total detik.
 * Contoh: "1:15:20" -> 4520
 */
function timeToSeconds(str) {
  const parts = str.trim().split(":").map((p) => p.trim());
  if (parts.some((p) => p === "" || isNaN(Number(p)))) return null;

  let seconds = 0;
  if (parts.length === 3) {
    const [h, m, s] = parts.map(Number);
    seconds = h * 3600 + m * 60 + s;
  } else if (parts.length === 2) {
    const [m, s] = parts.map(Number);
    seconds = m * 60 + s;
  } else if (parts.length === 1) {
    seconds = Number(parts[0]);
  } else {
    return null;
  }
  return seconds >= 0 ? seconds : null;
}

/**
 * Format total detik ke "H:MM:SS" (dipakai buat argumen ffmpeg/yt-dlp).
 */
function secondsToTime(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  return [h, m, s].map((n) => String(n).padStart(2, "0")).join(":");
}

module.exports = { timeToSeconds, secondsToTime };
