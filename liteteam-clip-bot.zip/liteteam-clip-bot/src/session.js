// Penyimpanan sesi sementara per user (in-memory, hilang kalau bot restart).
// Untuk kebutuhan personal/kecil ini cukup — tidak perlu database eksternal (tetap free).

const sessions = new Map();

function getSession(chatId) {
  if (!sessions.has(chatId)) {
    sessions.set(chatId, {});
  }
  return sessions.get(chatId);
}

function resetSession(chatId) {
  sessions.set(chatId, {});
}

module.exports = { getSession, resetSession };
