const path = require("path");
const fs = require("fs");
const ffmpeg = require("fluent-ffmpeg");
const ffmpegPath = require("ffmpeg-static");
const ffprobePath = require("ffprobe-static").path;
const { DEFAULT_THUMBNAIL_FONT } = require("../config");

ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobePath);

function getDuration(videoPath) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(videoPath, (err, data) => {
      if (err) return reject(err);
      resolve(data.format.duration || 0);
    });
  });
}

/**
 * Pecah teks jadi maksimal `maxLines` baris, tiap baris dibatasi panjang karakter,
 * biar teks hook di thumbnail gak kepanjangan satu baris & tetap kebaca jelas.
 */
function wrapText(text, maxCharsPerLine = 20, maxLines = 2) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines = [];
  let current = "";

  for (const w of words) {
    const candidate = (current + " " + w).trim();
    if (candidate.length > maxCharsPerLine && current) {
      lines.push(current.trim());
      current = w;
      if (lines.length === maxLines) break;
    } else {
      current = candidate;
    }
  }
  if (lines.length < maxLines && current) lines.push(current.trim());

  return lines.slice(0, maxLines).join("\n");
}

/**
 * Generate thumbnail otomatis dari video: ambil 1 frame (dari sekitar 35%
 * durasi klip — biasanya bukan frame transisi/hitam di awal/akhir), lalu
 * tempelkan teks hook besar & bold ala thumbnail YouTube yang 'nge-klik'.
 *
 * @param {string} videoPath
 * @param {string} hookText - biasanya judul video, dipendekkan otomatis
 * @param {{fontPath?: string, colorHex?: string}} style
 * @param {string} outputPath - harus .jpg
 */
async function generateThumbnail(videoPath, hookText, style = {}, outputPath) {
  const duration = await getDuration(videoPath);
  const seekTime = Math.max(0.5, duration * 0.35);

  const workDir = path.dirname(outputPath);
  const textFile = path.join(workDir, `hook_${Date.now()}.txt`);
  const wrapped = wrapText((hookText || "CLIP VIRAL").toUpperCase(), 20, 2);
  fs.writeFileSync(textFile, wrapped, "utf-8");

  const font = style.fontPath || DEFAULT_THUMBNAIL_FONT;
  const color = style.colorHex || "#FFFFFF";
  const escapedTextFile = textFile.replace(/:/g, "\\:");
  const escapedFont = font.replace(/:/g, "\\:");

  const drawtext =
    `drawtext=textfile='${escapedTextFile}':fontfile='${escapedFont}':fontsize=88:` +
    `fontcolor=${color}:borderw=8:bordercolor=black:line_spacing=14:` +
    `x=(w-text_w)/2:y=h-th-90:box=1:boxcolor=black@0.25:boxborderw=24`;

  return new Promise((resolve, reject) => {
    ffmpeg(videoPath)
      .seekInput(seekTime)
      .videoFilters([
        `scale=1280:720:force_original_aspect_ratio=increase`,
        `crop=1280:720`,
        drawtext,
      ])
      .outputOptions(["-frames:v", "1", "-q:v", "2"])
      .on("error", reject)
      .on("end", () => {
        try {
          fs.unlinkSync(textFile);
        } catch (_) {
          /* abaikan */
        }
        resolve(outputPath);
      })
      .save(outputPath);
  });
}

module.exports = { generateThumbnail };
