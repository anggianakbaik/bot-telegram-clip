const youtubedl = require("youtube-dl-exec");
const path = require("path");
const { secondsToTime } = require("../utils/time");

/**
 * Download hanya bagian video yang dibutuhkan (bukan full video) dari YouTube,
 * pakai fitur --download-sections milik yt-dlp. Ini menghemat waktu & storage
 * karena tidak perlu download video 3 jam penuh cuma buat ambil clip 15 menit.
 *
 * @param {string} url - Link YouTube
 * @param {number} startSec - Detik mulai
 * @param {number} endSec - Detik akhir
 * @param {string} outputDir - Folder temp untuk menyimpan hasil
 * @returns {Promise<string>} path file hasil download
 */
async function downloadYoutubeSection(url, startSec, endSec, outputDir) {
  const start = secondsToTime(startSec);
  const end = secondsToTime(endSec);
  const outputTemplate = path.join(outputDir, "source_%(id)s.%(ext)s");

  await youtubedl(url, {
    output: outputTemplate,
    format: "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
    downloadSections: `*${start}-${end}`,
    forceKeyframesAtCuts: true,
    noPlaylist: true,
    mergeOutputFormat: "mp4",
  });

  // yt-dlp mengganti %(id)s dengan id video asli, jadi kita cari file yang baru dibuat
  const fs = require("fs");
  const files = fs
    .readdirSync(outputDir)
    .filter((f) => f.startsWith("source_"))
    .map((f) => ({ f, t: fs.statSync(path.join(outputDir, f)).mtimeMs }))
    .sort((a, b) => b.t - a.t);

  if (files.length === 0) {
    throw new Error("Download gagal, file hasil tidak ditemukan.");
  }
  return path.join(outputDir, files[0].f);
}

module.exports = { downloadYoutubeSection };
