const ffmpeg = require("fluent-ffmpeg");
const ffmpegPath = require("ffmpeg-static");
const ffprobePath = require("ffprobe-static").path;

ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobePath);

/**
 * Ubah orientasi video (potret 9:16 / lanskap 16:9) — HASIL MAKSIMAL:
 *
 * 1. "Pad + blur background": frame video ASLI tetap utuh 100% (tidak ada
 *    yang kepotong kayak hard-crop biasa). Ruang kosong di kiri-kanan
 *    (atau atas-bawah) diisi versi blur dari video itu sendiri sebagai
 *    latar — ini gaya yang dipakai kreator clip/short profesional, jauh
 *    lebih enak dilihat dibanding video yang dipotong paksa atau ada
 *    bar hitam polos.
 * 2. Loudness normalization (loudnorm, target -14 LUFS, standar YouTube) —
 *    volume jadi konsisten & enak didengar tanpa penonton perlu naik-turunin
 *    volume, ini kecil tapi ngaruh besar ke retensi penonton.
 * 3. Color grading tipis (kontras & saturasi naik dikit) — visual jadi lebih
 *    'pop' dan gak keliatan flat/pucat.
 *
 * @param {string} inputPath
 * @param {string} outputPath
 * @param {"portrait"|"landscape"} orientation
 */
function processOrientation(inputPath, outputPath, orientation) {
  return new Promise((resolve, reject) => {
    const isPortrait = orientation === "portrait";
    const targetW = isPortrait ? 1080 : 1920;
    const targetH = isPortrait ? 1920 : 1080;

    ffmpeg(inputPath)
      .complexFilter([
        // Duplikat video jadi 2 stream: satu buat background (blur), satu buat foreground (utuh)
        { filter: "split", options: "2", inputs: "0:v", outputs: ["bg", "fg"] },

        // Background: scale sampai penuhi seluruh frame target (boleh kepotong dikit), lalu blur
        {
          filter: "scale",
          options: { w: targetW, h: targetH, force_original_aspect_ratio: "increase" },
          inputs: "bg",
          outputs: "bgscaled",
        },
        { filter: "crop", options: `${targetW}:${targetH}`, inputs: "bgscaled", outputs: "bgcropped" },
        { filter: "gblur", options: { sigma: 30 }, inputs: "bgcropped", outputs: "bgblur" },
        { filter: "eq", options: { brightness: -0.06 }, inputs: "bgblur", outputs: "bgfinal" },

        // Foreground: scale supaya MUAT SELURUHNYA di dalam frame target (tidak ada yang kepotong)
        {
          filter: "scale",
          options: { w: targetW, h: targetH, force_original_aspect_ratio: "decrease" },
          inputs: "fg",
          outputs: "fgscaled",
        },
        {
          filter: "eq",
          options: { contrast: 1.05, saturation: 1.15 },
          inputs: "fgscaled",
          outputs: "fgfinal",
        },

        // Tumpuk foreground di tengah-tengah background blur
        {
          filter: "overlay",
          options: { x: "(W-w)/2", y: "(H-h)/2" },
          inputs: ["bgfinal", "fgfinal"],
          outputs: "vout",
        },
      ])
      .outputOptions([
        "-map", "[vout]",
        "-map", "0:a?",
        "-preset", "medium",
        "-crf", "17",
        "-pix_fmt", "yuv420p",
      ])
      .videoCodec("libx264")
      .audioCodec("aac")
      .audioBitrate("192k")
      .audioFilters("loudnorm=I=-14:TP=-1.5:LRA=11")
      .on("error", reject)
      .on("end", () => resolve(outputPath))
      .save(outputPath);
  });
}

module.exports = { processOrientation };
