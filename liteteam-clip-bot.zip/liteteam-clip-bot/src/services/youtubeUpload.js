const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");

const ROOT = path.join(__dirname, "..", "..");
const CLIENT_SECRET_FILE = path.join(ROOT, "client_secret.json");
const TOKEN_FILE = path.join(ROOT, "token.json");

function getAuthClient() {
  if (!fs.existsSync(CLIENT_SECRET_FILE) || !fs.existsSync(TOKEN_FILE)) {
    throw new Error(
      "client_secret.json / token.json belum ada. Jalankan authorize.js dulu di PC lokal " +
        "lalu upload token.json ke panel (lihat README)."
    );
  }

  const { client_id, client_secret, redirect_uris } = JSON.parse(
    fs.readFileSync(CLIENT_SECRET_FILE)
  ).installed;

  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
  const token = JSON.parse(fs.readFileSync(TOKEN_FILE));
  oAuth2Client.setCredentials(token);

  // Simpan ulang token kalau di-refresh otomatis (access_token baru)
  oAuth2Client.on("tokens", (newTokens) => {
    const merged = { ...token, ...newTokens };
    fs.writeFileSync(TOKEN_FILE, JSON.stringify(merged, null, 2));
  });

  return oAuth2Client;
}

/**
 * Upload video ke YouTube, opsional langsung set thumbnail custom juga.
 * @param {object} opts { videoPath, judul, deskripsi, hashtags, tipe, privasi, thumbnailPath, onProgress }
 * @returns {Promise<{videoId: string, thumbnailSet: boolean}>}
 */
async function uploadVideo({
  videoPath,
  judul,
  deskripsi,
  hashtags = [],
  tipe = "long",
  privasi = "public",
  thumbnailPath = null,
  onProgress,
}) {
  const auth = getAuthClient();
  const youtube = google.youtube({ version: "v3", auth });

  const tags = hashtags.map((h) => h.replace(/^#/, ""));
  let finalDesc = deskripsi || "";
  if (hashtags.length) {
    finalDesc = `${finalDesc}\n\n${hashtags.map((h) => (h.startsWith("#") ? h : `#${h}`)).join(" ")}`.trim();
  }
  if (tipe === "shorts" && !finalDesc.toLowerCase().includes("#shorts")) {
    finalDesc = `${finalDesc}\n\n#Shorts`.trim();
  }

  const fileSize = fs.statSync(videoPath).size;

  const res = await youtube.videos.insert(
    {
      part: "snippet,status",
      requestBody: {
        snippet: {
          title: judul.slice(0, 100),
          description: finalDesc.slice(0, 5000),
          tags,
          categoryId: "22",
        },
        status: {
          privacyStatus: privasi,
          selfDeclaredMadeForKids: false,
        },
      },
      media: {
        body: fs.createReadStream(videoPath),
      },
    },
    {
      onUploadProgress: (evt) => {
        if (onProgress) {
          const percent = Math.round((evt.bytesRead / fileSize) * 100);
          onProgress(Math.min(percent, 100));
        }
      },
    }
  );

  const videoId = res.data.id;
  let thumbnailSet = false;

  if (thumbnailPath && fs.existsSync(thumbnailPath)) {
    try {
      await youtube.thumbnails.set({
        videoId,
        media: { body: fs.createReadStream(thumbnailPath) },
      });
      thumbnailSet = true;
    } catch (err) {
      // Custom thumbnail via API butuh channel yang sudah verified (nomor HP).
      // Kalau gagal, video tetap terupload normal — cuma pakai thumbnail
      // auto-pilih YouTube, bukan error fatal.
      console.warn("⚠️ Gagal set custom thumbnail:", err.message);
    }
  }

  return { videoId, thumbnailSet };
}

module.exports = { uploadVideo };
