const path = require("path");
const fs = require("fs");
const ffmpeg = require("fluent-ffmpeg");
const ffmpegPath = require("ffmpeg-static");
const fontkit = require("fontkit");
const { hexToAssColor } = require("../utils/color");
const { DEFAULT_SUBTITLE_FONT, DEFAULT_FONTS_DIR } = require("../config");

ffmpeg.setFfmpegPath(ffmpegPath);

// ------------------------------------------------------------------
// Transkrip (whisper.cpp lokal, gratis)
// ------------------------------------------------------------------
/**
 * CATATAN SETUP:
 * - Run pertama kali akan otomatis download model whisper (butuh internet sekali).
 * - Butuh build tools (make, g++/gcc) tersedia di environment/container.
 */
async function transcribeToSrt(inputPath, lang = "id") {
  const { nodewhisper } = require("nodejs-whisper");

  await nodewhisper(inputPath, {
    modelName: "base",
    autoDownloadModelName: "base",
    removeWavFileAfterTranscription: true,
    whisperOptions: {
      outputInSrt: true,
      language: lang,
      translateToEnglish: false,
      wordTimestamps: false,
    },
  });

  const base = inputPath.replace(path.extname(inputPath), "");
  const srtPath = `${base}.srt`;

  if (!fs.existsSync(srtPath)) {
    throw new Error(
      "File .srt tidak ditemukan setelah transkrip. Cek log nodejs-whisper untuk detail error."
    );
  }
  return srtPath;
}

// ------------------------------------------------------------------
// Parse .srt jadi segmen {start, end, text} (detik)
// ------------------------------------------------------------------
function srtTimeToSeconds(t) {
  const [h, m, rest] = t.trim().split(":");
  const [s, ms] = rest.split(",");
  return Number(h) * 3600 + Number(m) * 60 + Number(s) + Number(ms) / 1000;
}

function parseSrt(content) {
  const blocks = content.replace(/\r/g, "").trim().split(/\n\n+/);
  const segments = [];

  for (const block of blocks) {
    const lines = block.split("\n").filter(Boolean);
    const timeLine = lines.find((l) => l.includes("-->"));
    if (!timeLine) continue;

    const [startStr, endStr] = timeLine.split("-->").map((s) => s.trim());
    const text = lines.slice(lines.indexOf(timeLine) + 1).join(" ").trim();
    if (!text) continue;

    segments.push({
      start: srtTimeToSeconds(startStr),
      end: srtTimeToSeconds(endStr),
      text,
    });
  }
  return segments;
}

/**
 * Pecah tiap segmen kalimat whisper jadi frasa pendek (default 4 kata) supaya
 * caption tampil cepat & catchy kayak gaya editor Shorts/TikTok/Reels — bukan
 * satu kalimat panjang yang nongol lama di layar.
 * Waktu tiap frasa diinterpolasi proporsional dari jumlah kata dalam segmen asli.
 */
function rechunkSegments(segments, maxWords = 4) {
  const chunks = [];
  for (const seg of segments) {
    const words = seg.text.split(/\s+/).filter(Boolean);
    if (words.length === 0) continue;

    const duration = seg.end - seg.start;
    const totalWords = words.length;

    for (let i = 0; i < totalWords; i += maxWords) {
      const group = words.slice(i, i + maxWords);
      const startWord = i;
      const endWord = i + group.length;
      chunks.push({
        start: seg.start + (duration * startWord) / totalWords,
        end: seg.start + (duration * endWord) / totalWords,
        text: group.join(" "),
      });
    }
  }
  return chunks;
}

// ------------------------------------------------------------------
// Helper ASS (Advanced SubStation Alpha)
// ------------------------------------------------------------------
function secondsToAss(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const cs = Math.round((sec - Math.floor(sec)) * 100);
  return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
}

function getFontFamilyName(fontPath) {
  try {
    const font = fontkit.openSync(fontPath);
    return font.familyName || path.basename(fontPath, path.extname(fontPath));
  } catch (err) {
    return path.basename(fontPath, path.extname(fontPath));
  }
}

function escapeAssText(text) {
  return text.replace(/\\/g, "\\\\").replace(/\{/g, "\\{").replace(/\}/g, "\\}");
}

/**
 * Generate file .ass lengkap dengan style + animasi "pop" tiap frasa muncul,
 * dari hasil transkrip whisper (.srt).
 */
function buildAssFromSrt(srtPath, { fontPath, colorHex, orientation, outputPath }) {
  const raw = fs.readFileSync(srtPath, "utf-8");
  const chunks = rechunkSegments(parseSrt(raw), 4);

  const fontName = getFontFamilyName(fontPath || DEFAULT_SUBTITLE_FONT);
  const assColor = hexToAssColor(colorHex || "#FFFFFF");
  const isPortrait = orientation === "portrait";

  const fontSize = isPortrait ? 78 : 58;
  const marginV = isPortrait ? 260 : 90; // portrait dikasih margin lebih besar biar gak ketutup UI Shorts
  const playResX = isPortrait ? 1080 : 1920;
  const playResY = isPortrait ? 1920 : 1080;

  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: ${playResX}
PlayResY: ${playResY}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,${fontName},${fontSize},${assColor},&H000000FF&,&H00000000&,&H64000000&,-1,0,0,0,100,100,0,0,1,4,2,2,60,60,${marginV},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const lines = chunks.map((c) => {
    const start = secondsToAss(c.start);
    const end = secondsToAss(Math.max(c.end, c.start + 0.3));
    const text = escapeAssText(c.text.toUpperCase());
    // Animasi pop: mulai 70% ukuran lalu membesar ke 100% dalam 120ms + fade in/out singkat
    const animated = `{\\fad(60,60)\\fscx70\\fscy70\\t(0,120,\\fscx100\\fscy100)}${text}`;
    return `Dialogue: 0,${start},${end},Default,,0,0,0,,${animated}`;
  });

  fs.writeFileSync(outputPath, header + lines.join("\n") + "\n", "utf-8");
  return outputPath;
}

/**
 * Burn file .ass (sudah lengkap dengan style & animasi) ke video.
 * Audio di-copy langsung (bukan re-encode) karena tahap ini cuma
 * mengubah gambar, biar tidak ada penurunan kualitas audio tambahan.
 */
function burnSubtitle(videoPath, assPath, fontDir, outputPath) {
  return new Promise((resolve, reject) => {
    const escapedAss = assPath.replace(/:/g, "\\:").replace(/'/g, "\\'");
    const dir = (fontDir || DEFAULT_FONTS_DIR).replace(/:/g, "\\:");

    ffmpeg(videoPath)
      .videoFilters(`ass='${escapedAss}':fontsdir='${dir}'`)
      .videoCodec("libx264")
      .outputOptions(["-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p"])
      .audioCodec("copy")
      .on("error", reject)
      .on("end", () => resolve(outputPath))
      .save(outputPath);
  });
}

module.exports = { transcribeToSrt, buildAssFromSrt, burnSubtitle, getFontFamilyName };
