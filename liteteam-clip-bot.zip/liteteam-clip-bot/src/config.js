const path = require("path");

const ROOT = path.join(__dirname, "..");

module.exports = {
  ROOT,
  FONTS_DIR: path.join(ROOT, "fonts"),
  DEFAULT_FONTS_DIR: path.join(ROOT, "fonts", "default"),
  // Font bawaan (bundled) — dipakai kalau user tidak upload font sendiri.
  // Poppins Bold: enak dibaca, dipakai buat subtitle.
  // Anton: bold & impactful, dipakai buat teks hook di thumbnail.
  // Keduanya lisensi SIL Open Font License (gratis, boleh dipakai & didistribusikan).
  DEFAULT_SUBTITLE_FONT: path.join(ROOT, "fonts", "default", "Poppins-Bold.ttf"),
  DEFAULT_THUMBNAIL_FONT: path.join(ROOT, "fonts", "default", "Anton-Regular.ttf"),
  TEMP_DIR: path.join(ROOT, "temp"),
};
