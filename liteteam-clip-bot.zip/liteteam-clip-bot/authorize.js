/**
 * JALANKAN INI DI PC/LAPTOP KAMU SENDIRI (BUKAN DI PANEL PTERODACTYL).
 *
 * Kenapa? Karena proses login OAuth Google butuh buka browser & redirect ke
 * "localhost", yang cuma bisa jalan normal di komputer yang punya browser.
 * Panel/VPS biasanya headless (tanpa browser).
 *
 * Cara pakai:
 * 1. Taruh file client_secret.json (dari Google Cloud Console) di folder ini.
 * 2. Jalankan: node authorize.js
 * 3. Browser bakal kebuka, login & authorize akun YouTube kamu.
 * 4. Setelah selesai, file "token.json" otomatis dibuat di folder ini.
 * 5. Upload file "token.json" itu ke panel Pterodactyl, taruh di folder yang sama
 *    dengan bot (sejajar dengan index.js).
 *
 * Token ini yang dipakai bot buat upload ke YouTube tanpa perlu login ulang.
 */

const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");
const http = require("http");
const url = require("url");

const CLIENT_SECRET_FILE = path.join(__dirname, "client_secret.json");
const TOKEN_FILE = path.join(__dirname, "token.json");
const SCOPES = ["https://www.googleapis.com/auth/youtube.upload"];

async function main() {
  if (!fs.existsSync(CLIENT_SECRET_FILE)) {
    console.error("❌ client_secret.json tidak ditemukan di folder ini.");
    console.error("   Download dari Google Cloud Console (OAuth Client ID - Desktop App).");
    process.exit(1);
  }

  const { client_id, client_secret, redirect_uris } = JSON.parse(
    fs.readFileSync(CLIENT_SECRET_FILE)
  ).installed;

  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: "offline",
    scope: SCOPES,
    prompt: "consent",
  });

  console.log("\nBuka link ini di browser buat login & authorize:\n");
  console.log(authUrl);
  console.log("\nMenunggu proses authorize...\n");

  const redirectUrl = new URL(redirect_uris[0]);
  const port = Number(redirectUrl.port) || 80;

  const server = http.createServer(async (req, res) => {
    const qs = new url.URL(req.url, `http://localhost:${port}`).searchParams;
    const code = qs.get("code");

    if (code) {
      res.end("✅ Authorize berhasil! Kamu bisa tutup tab ini dan kembali ke terminal.");
      server.close();

      const { tokens } = await oAuth2Client.getToken(code);
      fs.writeFileSync(TOKEN_FILE, JSON.stringify(tokens, null, 2));
      console.log("✅ token.json berhasil dibuat di:", TOKEN_FILE);
      console.log("   Upload file ini ke panel Pterodactyl, sejajar dengan index.js.");
    } else {
      res.end("❌ Gagal mendapatkan kode authorize.");
    }
  });

  server.listen(port, () => {
    console.log(`(server lokal menunggu redirect di port ${port}...)`);
  });
}

main();
