require("dotenv").config();
const { Telegraf, Scenes, session } = require("telegraf");
const clipScene = require("./src/scenes/clipScene");

if (!process.env.BOT_TOKEN) {
  console.error("❌ BOT_TOKEN belum diset di file .env");
  process.exit(1);
}

const bot = new Telegraf(process.env.BOT_TOKEN);
const stage = new Scenes.Stage([clipScene]);

bot.use(session());
bot.use(stage.middleware());

// Batasi bot cuma bisa dipakai user tertentu (opsional, isi ALLOWED_USER_ID di .env)
bot.use((ctx, next) => {
  const allowed = process.env.ALLOWED_USER_ID;
  if (allowed && String(ctx.from?.id) !== String(allowed)) {
    return ctx.reply("🚫 Bot ini private, kamu tidak punya akses.");
  }
  return next();
});

bot.start((ctx) =>
  ctx.reply(
    "👋 Halo! Ini *Lite Team Clip* bot.\n\n" +
      "Perintah:\n" +
      "/clip - mulai bikin clip video dari YouTube\n" +
      "/cancel - batalkan proses yang sedang jalan",
    { parse_mode: "Markdown" }
  )
);

bot.command("clip", (ctx) => ctx.scene.enter("CLIP_SCENE"));

bot.command("cancel", async (ctx) => {
  if (ctx.scene?.current) {
    await ctx.scene.leave();
    await ctx.reply("🚫 Dibatalkan.");
  } else {
    await ctx.reply("Tidak ada proses yang sedang berjalan.");
  }
});

bot.catch((err, ctx) => {
  console.error("Bot error:", err);
  ctx.reply(`❌ Terjadi error tak terduga: ${err.message}`).catch(() => {});
});

bot.launch();
console.log("🤖 Lite Team Clip bot berjalan...");

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
